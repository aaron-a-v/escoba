package escoba;

public class Card {
    private int num;
    private int value;
    private String stick;

    //métodos
    public Card() {
    }

    public Card(int num, int value, String stick) {
        this.num = num;
        this.value = value;
        this.stick = stick;
    }
    
    public int getNum(){
        return num;
    }
    
    public int getValue(){
        return value;
    }
    
    public String getStick(){
        return stick;
    }
    
    public void isSevenOfGold(){}
    
    //toString(){}
    
    
}
