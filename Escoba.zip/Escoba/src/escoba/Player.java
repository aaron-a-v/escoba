package escoba;
import java.util.ArrayList;

public abstract class Player {
    private String name;
    private int points;
    private int escobas;
    private ArrayList<Card> hand = new ArrayList<>();
    private ArrayList<Card> capturedCards = new ArrayList<>();
    
    
    //métodos
    public Player(String name, int points, int escobas){
        this.name = name;
        this.points = points;
        this.escobas = escobas;
    }
    
    public int getEscobas(){
        return escobas;
    }
    
    public int getPoints(){
        return points;
    }
    
    public void addPoints(){}
    
    //toString
    
}
