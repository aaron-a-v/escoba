package escoba;
import java.util.ArrayList;

public class Table {
    private ArrayList<Card> deck = new ArrayList<>();
    private ArrayList<Card> onTableCards = new ArrayList<>();
    
    //métodos
    public Table(){}
    
    public void shuffleDeck(){}
    public void dealInitial(){}
    public void drawFromDeck(){}
    
    public ArrayList<Card> getOnTableCards(){
        return onTableCards;
    }
    
    public void addCardsToTable(){}
    public void removeCardsToTable(){}
    
}
